<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/all.min.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/bootstrap.min.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/h-2-carousel.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/jquery.webui-popover.min.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/nice-select.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/owl.carousel.min.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/owl.theme.default.min.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/slick-theme.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/slick.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/swiper-bundle.min.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/style.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/new-style.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/responsive.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/summernote-0.8.20-dist/summernote-lite.min.css'; ?>">

<link rel="stylesheet" href="<?php echo base_url() . 'assets/global/tagify/tagify.css'; ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/global/toastr/toastr.css' ?>">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/frontend/default-new/css/custom.css'; ?>">

<script src="<?php echo base_url('assets/global/js/jquery-3.6.1.min.js'); ?>"></script>


