<?php include "breadcrumb.php"; ?>

<div class="container py-5">
	<?php echo remove_js(htmlspecialchars_decode_($page_content)); ?>
</div>